
fitness=simulation(23,50,10,10,50);

